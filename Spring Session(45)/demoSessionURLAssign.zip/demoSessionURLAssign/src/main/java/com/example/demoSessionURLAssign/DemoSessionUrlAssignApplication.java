package com.example.demoSessionURLAssign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSessionUrlAssignApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSessionUrlAssignApplication.class, args);
	}

}
