package com.example.demoemployeehttp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoemployeehttpApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoemployeehttpApplication.class, args);
	}

}
