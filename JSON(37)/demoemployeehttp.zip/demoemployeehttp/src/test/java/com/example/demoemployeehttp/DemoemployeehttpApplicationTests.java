package com.example.demoemployeehttp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoemployeehttpApplicationTests {

	@Test
	void contextLoads() {
	}

}
