package com.example.demoSpringsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringsecurityApplication.class, args);
	}

}
