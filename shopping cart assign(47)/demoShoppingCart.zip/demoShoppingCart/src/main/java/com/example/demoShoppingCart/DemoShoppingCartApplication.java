package com.example.demoShoppingCart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoShoppingCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoShoppingCartApplication.class, args);
	}

}
