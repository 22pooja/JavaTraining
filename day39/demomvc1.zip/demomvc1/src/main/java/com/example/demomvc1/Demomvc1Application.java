package com.example.demomvc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demomvc1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demomvc1Application.class, args);
	}

}
