package com.example.demowebsession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowebsessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
