package com.example.demowebappAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowebappAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
