package com.example.demowebsession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemowebsessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemowebsessionApplication.class, args);
	}

}
