package com.example.demoMvcHtmlallTag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMvcHtmlAllTagApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvcHtmlAllTagApplication.class, args);
	}

}
