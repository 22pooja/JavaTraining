package com.example.demojpawebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemojpawebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
