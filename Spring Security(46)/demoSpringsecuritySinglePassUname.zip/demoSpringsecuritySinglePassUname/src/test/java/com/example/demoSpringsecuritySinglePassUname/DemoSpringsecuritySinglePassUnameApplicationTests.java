package com.example.demoSpringsecuritySinglePassUname;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringsecuritySinglePassUnameApplicationTests {

	@Test
	void contextLoads() {
	}

}
