package com.example.demoShoppingCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoShoppingCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
