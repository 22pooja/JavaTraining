package com.example.demoMvchtml1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMvchtml1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvchtml1Application.class, args);
	}

}
