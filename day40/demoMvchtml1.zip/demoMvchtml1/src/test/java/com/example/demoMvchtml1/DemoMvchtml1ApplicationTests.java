package com.example.demoMvchtml1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMvchtml1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
